
"use client";

import { useState } from "react";
import Link from "next/link";
import { Home, Store } from "lucide-react";

import { authClient } from "@/lib/auth-client";
import { getBackendToken } from "@/lib/getBackendToken";

export default function RequestRepairForm({ serviceId }) {
    const { data: session, isPending } = authClient.useSession();

    const [phone, setPhone] = useState("");
    const [address, setAddress] = useState("");
    const [preferredDate, setPreferredDate] = useState("");
    const [serviceMethod, setServiceMethod] = useState("");
    const [problemDescription, setProblemDescription] = useState("");

    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState("");
    const [success, setSuccess] = useState(false);

    const today = new Date().toLocaleDateString("en-CA", {
        timeZone: "Asia/Dhaka",
    });

    async function handleSubmit(e) {
        e.preventDefault();

        if (!serviceMethod) {
            setMessage("Please select a service method.");
            setSuccess(false);
            return;
        }

        if (problemDescription.trim().length < 20) {
            setMessage("Please describe your problem using at least 20 characters.");
            setSuccess(false);
            return;
        }

        setLoading(true);
        setMessage("");
        setSuccess(false);

        try {
            const token = await getBackendToken();

            if (!token) {
                throw new Error("Unable to verify your account. Please sign in again.");
            }

            const response = await fetch(
                `${process.env.NEXT_PUBLIC_API_URL}/api/bookings`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                    body: JSON.stringify({
                        serviceId,
                        phone,
                        address,
                        preferredDate,
                        serviceMethod,
                        problemDescription: problemDescription.trim(),
                    }),
                }
            );

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || "Failed to submit request");
            }

            setSuccess(true);
            setMessage("Your repair request was submitted successfully!");

            setPhone("");
            setAddress("");
            setPreferredDate("");
            setServiceMethod("");
            setProblemDescription("");

        } catch (error) {
            setMessage(error.message);
        } finally {
            setLoading(false);
        }
    }

    if (isPending) {
        return (
            <p className="mt-8 text-slate-500">
                Checking your account...
            </p>
        );
    }

    if (!session?.user) {
        return (
            <div className="mt-10 rounded-2xl border border-slate-200 bg-white p-7">
                <h2 className="text-2xl font-bold text-slate-900">
                    Request This Repair
                </h2>

                <p className="mt-3 text-slate-600">
                    Please sign in to request this repair service.
                </p>

                <Link
                    href="/sign-in"
                    className="mt-5 inline-block rounded-xl bg-orange-500 px-6 py-3 font-semibold text-white transition hover:bg-orange-600"
                >
                    Sign In to Continue
                </Link>
            </div>
        );
    }

    if (session.user.role !== "customer") {
        return (
            <div className="mt-10 rounded-2xl border border-amber-200 bg-amber-50 p-7">
                <h2 className="text-xl font-bold text-amber-800">
                    Repair Request Unavailable
                </h2>

                <p className="mt-2 text-amber-700">
                    Only customers can request a repair.
                </p>
            </div>
        );
    }

    return (
        <section className="mt-12 rounded-3xl border border-slate-200 bg-white p-7 shadow-sm">

            <h2 className="text-2xl font-bold text-slate-900">
                Request This Repair
            </h2>

            <p className="mt-2 text-slate-500">
                Fill in the information below to submit your repair request.
            </p>

            <form onSubmit={handleSubmit} className="mt-7 space-y-5">

                {/* Customer Information */}
                <div className="grid gap-5 sm:grid-cols-2">

                    <div>
                        <label className="mb-2 block text-sm font-semibold text-slate-700">
                            Customer Name
                        </label>

                        <input
                            type="text"
                            value={session.user.name || ""}
                            readOnly
                            className="w-full rounded-xl border border-slate-200 bg-slate-100 px-4 py-3 text-slate-600"
                        />
                    </div>

                    <div>
                        <label className="mb-2 block text-sm font-semibold text-slate-700">
                            Email Address
                        </label>

                        <input
                            type="email"
                            value={session.user.email || ""}
                            readOnly
                            className="w-full rounded-xl border border-slate-200 bg-slate-100 px-4 py-3 text-slate-600"
                        />
                    </div>

                </div>

                {/* Phone Number */}
                <div>
                    <label className="mb-2 block text-sm font-semibold text-slate-700">
                        Phone Number
                    </label>

                    <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="Enter your phone number"
                        required
                        className="w-full rounded-xl border border-slate-200 px-4 py-3 outline-none transition focus:border-orange-500 focus:ring-2 focus:ring-orange-100"
                    />
                </div>

                {/* Service Method */}
                <div>
                    <label className="mb-3 block text-sm font-semibold text-slate-700">
                        Choose Your Service Method
                    </label>

                    <div className="grid gap-4 sm:grid-cols-2">

                        {/* Home Service */}
                        <button
                            type="button"
                            onClick={() => setServiceMethod("Home Service")}
                            className={`rounded-2xl border-2 p-5 text-left transition ${
                                serviceMethod === "Home Service"
                                    ? "border-orange-500 bg-orange-50"
                                    : "border-slate-200 hover:border-orange-300"
                            }`}
                        >
                            <Home
                                size={30}
                                className="text-orange-500"
                            />

                            <h3 className="mt-3 font-bold text-slate-900">
                                Home Service
                            </h3>

                            <p className="mt-2 text-sm leading-6 text-slate-500">
                                The technician will visit your home and repair your item.
                            </p>

                            {serviceMethod === "Home Service" && (
                                <span className="mt-3 inline-block text-sm font-bold text-orange-600">
                                    ✓ Selected
                                </span>
                            )}
                        </button>

                        {/* Shop Drop-off */}
                        <button
                            type="button"
                            onClick={() => setServiceMethod("Shop Drop-off")}
                            className={`rounded-2xl border-2 p-5 text-left transition ${
                                serviceMethod === "Shop Drop-off"
                                    ? "border-orange-500 bg-orange-50"
                                    : "border-slate-200 hover:border-orange-300"
                            }`}
                        >
                            <Store
                                size={30}
                                className="text-orange-500"
                            />

                            <h3 className="mt-3 font-bold text-slate-900">
                                Shop Drop-off
                            </h3>

                            <p className="mt-2 text-sm leading-6 text-slate-500">
                                You will take your item to the technician's shop for repair.
                            </p>

                            {serviceMethod === "Shop Drop-off" && (
                                <span className="mt-3 inline-block text-sm font-bold text-orange-600">
                                    ✓ Selected
                                </span>
                            )}
                        </button>

                    </div>
                </div>

                {/* Repair Address */}
                <div>
                    <label className="mb-2 block text-sm font-semibold text-slate-700">
                        {serviceMethod === "Shop Drop-off"
                            ? "Your Contact Address"
                            : "Home Service Address"}
                    </label>

                    <textarea
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder={
                            serviceMethod === "Shop Drop-off"
                                ? "Enter your contact address"
                                : "Enter your complete home address"
                        }
                        rows={3}
                        required
                        className="w-full rounded-xl border border-slate-200 px-4 py-3 outline-none transition focus:border-orange-500 focus:ring-2 focus:ring-orange-100"
                    />

                    {serviceMethod === "Shop Drop-off" && (
                        <p className="mt-2 text-sm text-slate-500">
                            You will take your item to the technician's shop. This address is for customer contact purposes.
                        </p>
                    )}
                </div>

                {/* Preferred Date */}
                <div>
                    <label className="mb-2 block text-sm font-semibold text-slate-700">
                        Preferred Repair Date
                    </label>

                    <input
                        type="date"
                        value={preferredDate}
                        min={today}
                        onChange={(e) => setPreferredDate(e.target.value)}
                        required
                        className="w-full rounded-xl border border-slate-200 px-4 py-3 outline-none transition focus:border-orange-500 focus:ring-2 focus:ring-orange-100"
                    />
                </div>

                {/* Problem Description */}
                <div>
                    <label className="mb-2 block text-sm font-semibold text-slate-700">
                        Describe Your Problem
                    </label>

                    <textarea
                        value={problemDescription}
                        onChange={(e) => setProblemDescription(e.target.value)}
                        placeholder="Describe the appliance problem in at least 20 characters..."
                        rows={5}
                        minLength={20}
                        required
                        className="w-full rounded-xl border border-slate-200 px-4 py-3 outline-none transition focus:border-orange-500 focus:ring-2 focus:ring-orange-100"
                    />
                </div>

                {/* Success / Error Message */}
                {message && (
                    <div
                        className={`rounded-xl p-4 text-sm font-medium ${
                            success
                                ? "bg-green-50 text-green-700"
                                : "bg-red-50 text-red-700"
                        }`}
                    >
                        {message}
                    </div>
                )}

                {/* Submit Button */}
                <button
                    type="submit"
                    disabled={loading}
                    className="w-full rounded-xl bg-orange-500 px-6 py-4 font-bold text-white transition hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-60"
                >
                    {loading
                        ? "Submitting Request..."
                        : "Submit Repair Request"}
                </button>

            </form>
        </section>
    );
}
