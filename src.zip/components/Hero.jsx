
"use client";

import Image from "next/image";
import { useEffect, useState } from "react";
import {
    Search,
    MapPin,
    ArrowRight,
    ShieldCheck,
    ChevronLeft,
    ChevronRight,
} from "lucide-react";

export default function Hero() {

    const images = [
        "/images/PHONE-1.jpg",
        "/images/PHONE-2.jpg",
        "/images/PHONE-3.jpg",
        "/images/PHONE-4.jpg",
        "/images/PHONE-5.jpg",
        "/images/PHONE-6.jpg",
        "/images/PHONE-7.jpg",
    ];

    const [activeSlide, setActiveSlide] = useState(0);

    // Automatically change the image every 5 seconds
    useEffect(() => {
        const sliderInterval = setInterval(() => {
            setActiveSlide((previous) =>
                previous === images.length - 1 ? 0 : previous + 1
            );
        }, 5000);

        return () => clearInterval(sliderInterval);
    }, [images.length]);

    // Previous image
    const previousSlide = () => {
        setActiveSlide((previous) =>
            previous === 0 ? images.length - 1 : previous - 1
        );
    };

    // Next image
    const nextSlide = () => {
        setActiveSlide((previous) =>
            previous === images.length - 1 ? 0 : previous + 1
        );
    };

    return (
        <section className="relative min-h-[850px] w-full overflow-hidden bg-slate-900">

            {/* Background Image Slider */}
            {images.map((image, index) => (
                <div
                    key={image}
                    className={`absolute inset-0 transition-opacity duration-1000 ${
                        activeSlide === index ? "opacity-200" : "opacity-0"
                    }`}
                >
                    <Image
                        src={image}
                        alt={`FixMate home repair service ${index + 1}`}
                        fill
                        priority={index === 0}
                        sizes="100vw"
                        className="object-cover object-center"
                    />
                </div>
            ))}

            {/* Dark Overlay */}
            <div className="absolute inset-0 bg-slate-950/65" />

            {/* Hero Content */}
            <div className="relative z-10 mx-auto flex min-h-[750px] max-w-7xl flex-col items-center justify-center px-5 py-24 text-center">

                {/* Badge */}
                <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-4 py-2 text-sm font-medium text-white backdrop-blur-sm">
                    <ShieldCheck size={17} className="text-purple-400" />
                    Reliable Home Repair Services
                </div>

                {/* Heading */}
                <h1 className="max-w-4xl text-4xl font-extrabold leading-tight text-white sm:text-5xl md:text-6xl">
                    Your Home Deserves
                    <span className="block text-purple-400">
                        Expert Care
                    </span>
                </h1>

                {/* Description */}
                <p className="mt-5 max-w-2xl text-base leading-7 text-slate-200 sm:text-lg">
                    Find trusted technicians for your appliances.
                    Book professional repair services quickly and easily.
                </p>

                {/* Search Form */}
                <form
                    action="/services"
                    method="GET"
                    className="mt-10 flex w-full max-w-5xl flex-col gap-3 rounded-2xl bg-white p-3 shadow-2xl md:flex-row md:items-center md:rounded-xl"
                >

                    {/* Location */}
                    <div className="flex items-center gap-3 rounded-lg px-4 py-3 md:w-[230px]">
                        <MapPin className="shrink-0 text-purple-600" size={22} />

                        <div className="min-w-0 flex-1 text-left">
                            <label
                                htmlFor="area"
                                className="block text-xs font-semibold text-slate-500"
                            >
                                Your Location
                            </label>

                            <input
                                id="area"
                                name="area"
                                type="text"
                                placeholder="Enter your area"
                                className="w-full bg-transparent text-sm font-semibold text-slate-800 outline-none placeholder:font-normal placeholder:text-slate-400"
                            />
                        </div>
                    </div>

                    <div className="hidden h-12 w-px bg-slate-200 md:block" />

                    {/* Service Search */}
                    <div className="flex flex-1 items-center gap-3 rounded-lg px-4 py-3">
                        <Search className="shrink-0 text-slate-400" size={22} />

                        <input
                            type="text"
                            name="search"
                            placeholder="What needs to be repaired? e.g. AC, refrigerator, laptop..."
                            className="w-full bg-transparent text-sm text-slate-800 outline-none placeholder:text-slate-400"
                        />
                    </div>

                    {/* Search Button */}
                    <button
                        type="submit"
                        className="flex items-center justify-center gap-2 rounded-lg bg-purple-800 px-8 py-4 font-semibold text-white transition hover:bg-purple-900"
                    >
                        <Search size={19} />
                        <span>Search</span>
                        <ArrowRight size={17} />
                    </button>

                </form>

                <p className="mt-5 text-sm text-slate-300">
                    Find the right repair service for your home.
                </p>

            </div>

            {/* Previous Button */}
            <button
                onClick={previousSlide}
                aria-label="Previous slide"
                className="absolute left-4 top-1/2 z-20 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/30 bg-black/30 text-white backdrop-blur-sm transition hover:bg-white hover:text-purple-700 sm:left-8 sm:h-14 sm:w-14"
            >
                <ChevronLeft size={28} />
            </button>

            {/* Next Button */}
            <button
                onClick={nextSlide}
                aria-label="Next slide"
                className="absolute right-4 top-1/2 z-20 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/30 bg-black/30 text-white backdrop-blur-sm transition hover:bg-white hover:text-purple-700 sm:right-8 sm:h-14 sm:w-14"
            >
                <ChevronRight size={28} />
            </button>

            {/* Slide Indicators */}
            <div className="absolute bottom-8 left-1/2 z-20 flex -translate-x-1/2 items-center gap-2">
                {images.map((_, index) => (
                    <button
                        key={index}
                        onClick={() => setActiveSlide(index)}
                        aria-label={`Go to slide ${index + 1}`}
                        className={`h-2.5 rounded-full transition-all duration-300 ${
                            activeSlide === index
                                ? "w-8 bg-purple-400"
                                : "w-2.5 bg-white/60 hover:bg-white"
                        }`}
                    />
                ))}
            </div>

        </section>
    );
}
