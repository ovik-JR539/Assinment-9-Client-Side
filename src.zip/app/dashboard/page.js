
"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
    CalendarDays,
    ClipboardList,
    PlusCircle,
    UserRound,
    Users,
    Wrench,
    CreditCard,
    CheckCircle,
    Settings,
} from "lucide-react";

import { authClient } from "@/lib/auth-client";

export default function Dashboard() {
    const router = useRouter();

    const { data: session, isPending } = authClient.useSession();

    useEffect(() => {
        if (!isPending && !session) {
            router.replace("/sign-in");
        }
    }, [session, isPending, router]);

    if (isPending || !session) {
        return (
            <div className="flex min-h-[60vh] items-center justify-center">
                Checking your account...
            </div>
        );
    }

    const user = session.user;
    const role = user.role;

    // Customer navigation
    const customerMenu = [
        {
            name: "My Bookings",
            href: "/dashboard/my-bookings",
            icon: CalendarDays,
        },
        {
            name: "My Listings",
            href: "/dashboard/my-listings",
            icon: ClipboardList,
        },
        {
            name: "Add New Booking",
            href: "/dashboard/add-booking",
            icon: PlusCircle,
        },
        {
            name: "Profile Edit",
            href: "/dashboard/profile",
            icon: UserRound,
        },
    ];

    // Technician navigation
    // Pending Work removed
    const technicianMenu = [
        {
            name: "New Requests",
            href: "/dashboard/technician/requests",
            icon: ClipboardList,
        },
        {
            name: "My Services",
            href: "/dashboard/technician/services",
            icon: Wrench,
        },
        {
            name: "Profile Edit",
            href: "/dashboard/profile",
            icon: UserRound,
        },
    ];

    // Admin navigation
    const adminMenu = [
        {
            name: "Booking Progress",
            href: "/dashboard/admin/bookings",
            icon: CalendarDays,
        },
        {
            name: "Manage Users",
            href: "/dashboard/admin/users",
            icon: Users,
        },
        {
            name: "Approve Services",
            href: "/dashboard/admin/services",
            icon: CheckCircle,
        },
        {
            name: "Transactions",
            href: "/dashboard/admin/transactions",
            icon: CreditCard,
        },
        {
            name: "Profile Edit",
            href: "/dashboard/profile",
            icon: UserRound,
        },
    ];

    let menu = [];

    if (role === "customer") {
        menu = customerMenu;
    } else if (role === "technician") {
        menu = technicianMenu;
    } else if (role === "admin") {
        menu = adminMenu;
    }

    const colors = [
        "bg-teal-50 text-teal-700",
        "bg-blue-50 text-blue-700",
        "bg-purple-50 text-purple-700",
        "bg-orange-50 text-orange-700",
        "bg-rose-50 text-rose-700",
        "bg-indigo-50 text-indigo-700",
    ];

    return (
        <main className="min-h-screen bg-slate-50">
            <div className="max-w-7xl mx-auto">

                {/* Heading */}
                <div className="mb-8">
                    <p className="text-sm text-teal-700 font-semibold uppercase tracking-wider">
                        {role} dashboard
                    </p>

                    <h1 className="text-3xl font-bold text-slate-900 mt-2">
                        Welcome back, {user.name}!
                    </h1>

                    <p className="text-slate-500 mt-2">
                        Manage your FixMate account and activities from here.
                    </p>
                </div>

                {/* Account Overview */}
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm mb-8">
                    <h2 className="text-lg font-bold text-slate-900 mb-5">
                        Account Overview
                    </h2>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                        <div>
                            <p className="text-sm text-slate-500">
                                Full Name
                            </p>
                            <p className="font-semibold text-slate-900 mt-1">
                                {user.name}
                            </p>
                        </div>

                        <div>
                            <p className="text-sm text-slate-500">
                                Email Address
                            </p>
                            <p className="font-semibold text-slate-900 mt-1 break-all">
                                {user.email}
                            </p>
                        </div>

                        <div>
                            <p className="text-sm text-slate-500">
                                Account Role
                            </p>
                            <p className="font-semibold text-teal-700 capitalize mt-1">
                                {role}
                            </p>
                        </div>
                    </div>
                </div>

                {/* Quick Access */}
                <div className="mb-6">
                    <h2 className="text-xl font-bold text-slate-900">
                        Quick Access
                    </h2>

                    <p className="text-sm text-slate-500 mt-1">
                        Choose an option to manage your activities.
                    </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
                    {menu.map((item, index) => {
                        const Icon = item.icon;

                        return (
                            <Link
                                href={item.href}
                                key={item.name}
                                className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-teal-300 transition group"
                            >
                                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${colors[index % colors.length]}`}>
                                    <Icon size={23} />
                                </div>

                                <h3 className="font-bold text-slate-900 mt-5 group-hover:text-teal-700 transition">
                                    {item.name}
                                </h3>

                                <p className="text-sm text-slate-500 mt-2">
                                    Manage your {item.name.toLowerCase()}.
                                </p>

                                <p className="text-sm text-teal-700 font-semibold mt-5">
                                    Open section →
                                </p>
                            </Link>
                        );
                    })}
                </div>

                {/* Profile Section */}
                <div className="mt-8 bg-teal-50 border border-teal-100 rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div>
                        <h2 className="font-bold text-slate-900">
                            Keep your account updated
                        </h2>

                        <p className="text-sm text-slate-600 mt-1">
                            Update your personal information from your profile.
                        </p>
                    </div>

                    <Link
                        href="/dashboard/profile"
                        className="inline-flex justify-center items-center gap-2 bg-teal-700 hover:bg-teal-800 text-white px-5 py-3 rounded-xl font-semibold text-sm transition"
                    >
                        <Settings size={17} />
                        Edit Profile
                    </Link>
                </div>

            </div>
        </main>
    );
}
