
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import {
    CalendarDays,
    Search,
    RefreshCw,
    ClipboardList,
    Loader2,
    UserRound,
    Wrench,
    CheckCircle,
    XCircle,
    AlertCircle,
} from "lucide-react";

import { authClient } from "@/lib/auth-client";
import { getBackendToken } from "@/lib/getBackendToken";

export default function AdminBookingsPage() {
    const router = useRouter();
    const { data: session, isPending } = authClient.useSession();

    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [actionLoading, setActionLoading] = useState(null);

    const [searchTerm, setSearchTerm] = useState("");
    const [statusFilter, setStatusFilter] = useState("all");

    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");

    const API_URL = process.env.NEXT_PUBLIC_API_URL;

    // ADMIN AUTHENTICATION
    useEffect(() => {
        if (isPending) return;

        if (!session?.user) {
            router.push("/sign-in");
            return;
        }

        if (session.user.role !== "admin") {
            router.push("/");
        }
    }, [session, isPending, router]);

    // FETCH BOOKINGS
    const fetchBookings = async (isRefresh = false) => {
        try {
            if (isRefresh) {
                setRefreshing(true);
            } else {
                setLoading(true);
            }

            setError("");

            const token = await getBackendToken();

            if (!token) {
                throw new Error("Authentication token not found.");
            }

            const response = await fetch(
                `${API_URL}/api/bookings/admin-bookings`,
                {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                    cache: "no-store",
                }
            );

            const result = await response.json();

            if (!response.ok) {
                throw new Error(
                    result.message || "Failed to load bookings."
                );
            }

            setBookings(Array.isArray(result.data) ? result.data : []);
        } catch (err) {
            console.error("Fetch bookings error:", err);
            setError(err.message || "Unable to load bookings.");
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useEffect(() => {
        if (!isPending && session?.user?.role === "admin") {
            fetchBookings();
        }
    }, [session, isPending]);

    // APPROVE OR REJECT BOOKING
    const handleBookingAction = async (bookingId, action) => {
        const actionText = action === "approved" ? "approve" : "reject";

        const confirmed = window.confirm(
            `Are you sure you want to ${actionText} this booking?`
        );

        if (!confirmed) return;

        try {
            setActionLoading(bookingId);
            setError("");
            setSuccess("");

            const token = await getBackendToken();

            if (!token) {
                throw new Error("Authentication token not found.");
            }

            const response = await fetch(
                `${API_URL}/api/bookings/${bookingId}/admin-decision`,
                {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                    body: JSON.stringify({
                        status: action,
                    }),
                }
            );

            const result = await response.json();

            if (!response.ok) {
                throw new Error(
                    result.message || "Booking update failed."
                );
            }

            setBookings((previousBookings) =>
                previousBookings.map((booking) =>
                    booking._id === bookingId
                        ? { ...booking, status: action }
                        : booking
                )
            );

            setSuccess(`Booking ${action} successfully.`);
        } catch (err) {
            console.error("Booking action error:", err);
            setError(err.message || "Something went wrong.");
        } finally {
            setActionLoading(null);
        }
    };

    // FILTER BOOKINGS
    const filteredBookings = bookings.filter((booking) => {
        const search = searchTerm.toLowerCase();

        const matchesSearch =
            (booking.serviceTitle || booking.serviceName || "")
                .toLowerCase()
                .includes(search) ||
            (booking.customerName || "")
                .toLowerCase()
                .includes(search) ||
            (booking.customerEmail || "")
                .toLowerCase()
                .includes(search) ||
            (booking.technicianName || "")
                .toLowerCase()
                .includes(search);

        const matchesStatus =
            statusFilter === "all" ||
            booking.status === statusFilter;

        return matchesSearch && matchesStatus;
    });

    // LOADING
    if (isPending || loading) {
        return (
            <div className="flex min-h-[60vh] items-center justify-center">
                <div className="text-center">
                    <Loader2 className="mx-auto mb-3 h-10 w-10 animate-spin text-blue-600" />
                    <p className="text-gray-500">Loading bookings...</p>
                </div>
            </div>
        );
    }

    if (!session?.user || session.user.role !== "admin") {
        return null;
    }

    return (
        <div className="space-y-6">

            {/* HEADER */}
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
                <div>
                   <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
    Booking Management
</h1>

                    <p className="mt-1 text-sm text-gray-500">
                        Review customer bookings and approve or reject requests.
                    </p>
                </div>

                <button
                    onClick={() => fetchBookings(true)}
                    disabled={refreshing}
                    className="flex items-center justify-center gap-2 rounded-lg border border-gray-200 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 dark:border-gray-700 dark:text-gray-200 dark:hover:bg-gray-800"
                >
                    <RefreshCw
                        size={16}
                        className={refreshing ? "animate-spin" : ""}
                    />
                    Refresh
                </button>
            </div>

            {/* MESSAGES */}
            {error && (
                <div className="flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                    <AlertCircle size={18} />
                    {error}
                </div>
            )}

            {success && (
                <div className="flex items-center gap-2 rounded-lg border border-green-200 bg-green-50 p-3 text-sm text-green-700">
                    <CheckCircle size={18} />
                    {success}
                </div>
            )}

            {/* SUMMARY */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <SummaryCard
                    title="Total Bookings"
                    value={bookings.length}
                    icon={<ClipboardList size={22} />}
                />

                <SummaryCard
                    title="Waiting Approval"
                    value={
                        bookings.filter(
                            (booking) => booking.status === "requested"
                        ).length
                    }
                    icon={<CalendarDays size={22} />}
                    color="text-yellow-600"
                />

                <SummaryCard
                    title="Approved Bookings"
                    value={
                        bookings.filter(
                            (booking) => booking.status === "approved"
                        ).length
                    }
                    icon={<CheckCircle size={22} />}
                    color="text-green-600"
                />
            </div>

            {/* FILTERS */}
            <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-700 dark:bg-[#1c2029]">
                <div className="grid grid-cols-1 gap-3 md:grid-cols-2">

                    <div className="relative">
                        <Search
                            size={18}
                            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                        />

                        <input
                            type="text"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            placeholder="Search bookings..."
                            className="w-full rounded-lg border border-gray-200 bg-white py-2.5 pl-10 pr-3 text-sm outline-none focus:border-blue-500 dark:border-gray-600 dark:bg-[#111318] dark:text-white"
                        />
                    </div>

                    <select
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="rounded-lg border border-gray-200 bg-white px-3 py-2.5 text-sm outline-none dark:border-gray-600 dark:bg-[#111318] dark:text-white"
                    >
                        <option value="all">All Bookings</option>
                        <option value="requested">Requested</option>
                        <option value="approved">Approved</option>
                        <option value="accepted">Accepted</option>
                        <option value="in-progress">In Progress</option>
                        <option value="completed">Completed</option>
                        <option value="rejected">Rejected</option>
                        <option value="cancelled">Cancelled</option>
                    </select>

                </div>
            </div>

            {/* BOOKINGS TABLE */}
            <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-700 dark:bg-[#1c2029]">

                <div className="flex items-center justify-between border-b border-gray-200 px-5 py-4 dark:border-gray-700">
                    <h2 className="font-semibold text-gray-900 dark:text-white">
                        All Bookings
                    </h2>

                    <span className="text-sm text-gray-500">
                        {filteredBookings.length} bookings
                    </span>
                </div>

                {filteredBookings.length === 0 ? (
                    <div className="px-5 py-16 text-center">
                        <ClipboardList
                            size={42}
                            className="mx-auto mb-3 text-gray-300"
                        />

                        <h3 className="font-semibold text-gray-700 dark:text-gray-200">
                            No bookings found
                        </h3>

                        <p className="mt-1 text-sm text-gray-500">
                            Try changing your search or filter.
                        </p>
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full min-w-[1000px] text-left text-sm">

                            <thead className="bg-gray-50 text-xs uppercase text-gray-500 dark:bg-[#111318]">
                                <tr>
                                    <th className="px-5 py-4">Service</th>
                                    <th className="px-5 py-4">Customer</th>
                                    <th className="px-5 py-4">Technician</th>
                                    <th className="px-5 py-4">Booking Date</th>
                                    <th className="px-5 py-4">Actions</th>
                                </tr>
                            </thead>

                            <tbody className="divide-y divide-gray-100 dark:divide-gray-700">

                                {filteredBookings.map((booking) => (
                                    <tr
                                        key={booking._id}
                                        className="align-top hover:bg-gray-50 dark:hover:bg-[#252a35]"
                                    >

                                        {/* SERVICE IMAGE AND DESCRIPTION */}
                                        <td className="px-5 py-4">
                                            <div className="flex min-w-[300px] items-start gap-3">

                                                <img
                                                    src={
                                                        booking.serviceImage ||
                                                        booking.image ||
                                                        "/theme/Avater.png"
                                                    }
                                                    alt={
                                                        booking.serviceTitle ||
                                                        booking.serviceName ||
                                                        "Service"
                                                    }
                                                    className="h-16 w-16 shrink-0 rounded-lg object-cover"
                                                    onError={(e) => {
                                                        e.currentTarget.src = "/theme/Avater.png";
                                                    }}
                                                />

                                                <div>
                                                    <p className="font-semibold text-gray-900 dark:text-white">
                                                        {booking.serviceTitle ||
                                                            booking.serviceName ||
                                                            "Repair Service"}
                                                    </p>

                                                    <p className="mt-1 text-xs leading-5 text-gray-500">
                                                        {booking.problemDescription ||
                                                            booking.description ||
                                                            "No description"}
                                                    </p>

                                                    <br />

                                                    <p className="text-xs font-semibold text-gray-700 dark:text-gray-300">
                                                        Price: ৳
                                                        {Number(
                                                            booking.finalAmount ||
                                                            booking.totalAmount ||
                                                            booking.estimatedPrice ||
                                                            0
                                                        ).toLocaleString("en-BD")}
                                                    </p>
                                                </div>
                                            </div>
                                        </td>

                                        {/* CUSTOMER */}
                                        <td className="px-5 py-4">
                                            <div className="flex items-center gap-2">
                                                <UserRound
                                                    size={16}
                                                    className="text-gray-400"
                                                />

                                                <div>
                                                    <p className="font-medium text-gray-800 dark:text-gray-200">
                                                        {booking.customerName || "N/A"}
                                                    </p>

                                                    <p className="text-xs text-gray-500">
                                                        {booking.customerEmail || ""}
                                                    </p>
                                                </div>
                                            </div>
                                        </td>

                                        {/* TECHNICIAN */}
                                        <td className="px-5 py-4">
                                            <div className="flex items-center gap-2">
                                                <Wrench
                                                    size={16}
                                                    className="text-gray-400"
                                                />

                                                <div>
                                                    <p className="font-medium text-gray-800 dark:text-gray-200">
                                                        {booking.technicianName || "Not assigned"}
                                                    </p>

                                                    <p className="text-xs text-gray-500">
                                                        {booking.technicianEmail || ""}
                                                    </p>
                                                </div>
                                            </div>
                                        </td>

                                        {/* BOOKING DATE */}
                                        <td className="px-5 py-4">
                                            <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
                                                <CalendarDays
                                                    size={15}
                                                    className="text-gray-400"
                                                />

                                                <span className="whitespace-nowrap text-xs">
                                                    {booking.createdAt
                                                        ? new Date(
                                                            booking.createdAt
                                                        ).toLocaleDateString()
                                                        : "N/A"}
                                                </span>
                                            </div>
                                        </td>

                                        {/* APPROVE / REJECT */}
                                        <td className="px-5 py-4">
                                            {booking.status === "requested" ? (
                                                <div className="flex flex-col gap-2">

                                                    <button
                                                        onClick={() =>
                                                            handleBookingAction(
                                                                booking._id,
                                                                "approved"
                                                            )
                                                        }
                                                        disabled={
                                                            actionLoading === booking._id
                                                        }
                                                        className="flex items-center justify-center gap-1 rounded-lg bg-green-600 px-3 py-2 text-xs font-semibold text-white hover:bg-green-700 disabled:opacity-50"
                                                    >
                                                        {actionLoading === booking._id ? (
                                                            <Loader2
                                                                size={14}
                                                                className="animate-spin"
                                                            />
                                                        ) : (
                                                            <CheckCircle size={14} />
                                                        )}
                                                        Approve
                                                    </button>

                                                    <button
                                                        onClick={() =>
                                                            handleBookingAction(
                                                                booking._id,
                                                                "rejected"
                                                            )
                                                        }
                                                        disabled={
                                                            actionLoading === booking._id
                                                        }
                                                        className="flex items-center justify-center gap-1 rounded-lg bg-red-600 px-3 py-2 text-xs font-semibold text-white hover:bg-red-700 disabled:opacity-50"
                                                    >
                                                        {actionLoading === booking._id ? (
                                                            <Loader2
                                                                size={14}
                                                                className="animate-spin"
                                                            />
                                                        ) : (
                                                            <XCircle size={14} />
                                                        )}
                                                        Reject
                                                    </button>

                                                </div>
                                            ) : (
                                                <span className="text-xs text-gray-400">
                                                    No action needed
                                                </span>
                                            )}
                                        </td>

                                    </tr>
                                ))}

                            </tbody>
                        </table>
                    </div>
                )}

            </div>
        </div>
    );
}

// SUMMARY CARD
function SummaryCard({ title, value, icon, color = "text-blue-600" }) {
    return (
        <div className="rounded-xl border border-gray-200 bg-white p-5 dark:border-gray-700 dark:bg-[#1c2029]">
            <div className="flex items-center justify-between">
                <div>
                    <p className="text-sm text-gray-500">{title}</p>

                    <h3 className="mt-2 text-2xl font-bold text-gray-900 dark:text-white">
                        {value}
                    </h3>
                </div>

                <div className={color}>
                    {icon}
                </div>
            </div>
        </div>
    );
}
