"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { X, RefreshCw, Clock, ClipboardList } from "lucide-react";

import { authClient } from "@/lib/auth-client";
import { getBackendToken } from "@/lib/getBackendToken";

export default function TechnicianRequests() {
    const router = useRouter();

    const { data: session, isPending } = authClient.useSession();

    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [updating, setUpdating] = useState(false);
    const [error, setError] = useState("");
    const [message, setMessage] = useState("");

    const storageKey = session?.user?.email
        ? `fixmate-dismissed-requests:${session.user.email}`
        : null;

    useEffect(() => {
        if (isPending) return;

        if (!session) {
            router.push("/sign-in");
            return;
        }

        if (session.user.role !== "technician") {
            router.push("/dashboard");
            return;
        }

        fetchBookings();
    }, [session, isPending]);

    async function fetchBookings() {
        try {
            setLoading(true);
            setError("");

            const token = await getBackendToken();

            if (!token) {
                throw new Error(
                    "Authentication token not found. Please sign in again."
                );
            }

            const response = await fetch(
                `${process.env.NEXT_PUBLIC_API_URL}/api/bookings/technician-bookings`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                    cache: "no-store",
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Failed to load requests");
            }

            // Show pending and accepted bookings.
            const technicianBookings = (data.data || []).filter(
                (booking) =>
                    booking.status === "approved" ||
                    booking.status === "accepted" ||
                    booking.status === "in-progress"
            );

            // Get previously hidden booking IDs.
            const dismissedIds = storageKey
                ? JSON.parse(localStorage.getItem(storageKey) || "[]")
                : [];

            setBookings(
                technicianBookings.filter(
                    (booking) => !dismissedIds.includes(booking._id)
                )
            );
        } catch (error) {
            setError(error.message);
        } finally {
            setLoading(false);
        }
    }

    async function updateStatus(bookingId, status) {
        try {
            setUpdating(true);
            setError("");
            setMessage("");

            const token = await getBackendToken();

            if (!token) {
                throw new Error(
                    "Authentication token not found. Please sign in again."
                );
            }

            const response = await fetch(
                `${process.env.NEXT_PUBLIC_API_URL}/api/bookings/${bookingId}/status`,
                {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                    body: JSON.stringify({ status }),
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Failed to update request");
            }

            setMessage(
                data.message || `Request ${status} successfully.`
            );

            // Accepted bookings stay on the page.
            if (status === "accepted") {
                setBookings((previous) =>
                    previous.map((booking) =>
                        booking._id === bookingId
                            ? { ...booking, status: "accepted" }
                            : booking
                    )
                );
            }

            // Rejected bookings are removed from this page.
            if (status === "rejected") {
                setBookings((previous) =>
                    previous.filter(
                        (booking) => booking._id !== bookingId
                    )
                );
            }
        } catch (error) {
            setError(error.message);
        } finally {
            setUpdating(false);
        }
    }

    function dismissBooking(bookingId) {
        const dismissedIds = storageKey
            ? JSON.parse(localStorage.getItem(storageKey) || "[]")
            : [];

        if (!dismissedIds.includes(bookingId)) {
            dismissedIds.push(bookingId);
        }

        if (storageKey) {
            localStorage.setItem(
                storageKey,
                JSON.stringify(dismissedIds)
            );
        }

        setBookings((previous) =>
            previous.filter((booking) => booking._id !== bookingId)
        );
    }

    function clearAllBookings() {
        const currentIds = bookings.map((booking) => booking._id);

        const previousDismissed = storageKey
            ? JSON.parse(localStorage.getItem(storageKey) || "[]")
            : [];

        const updatedDismissed = [
            ...new Set([...previousDismissed, ...currentIds]),
        ];

        if (storageKey) {
            localStorage.setItem(
                storageKey,
                JSON.stringify(updatedDismissed)
            );
        }

        setBookings([]);
        setMessage("All request cards have been cleared.");
    }

    if (isPending || loading) {
        return (
            <div className="p-10 text-center text-slate-600">
                Loading repair requests...
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-slate-50 px-4 py-10">
            <div className="mx-auto max-w-7xl">

                {/* Header */}
                <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
                    <div>
                        <h1 className="text-3xl font-bold text-slate-900">
                            Customer Requests
                        </h1>

                        <p className="mt-2 text-slate-600">
                            Review new repair requests and accept or reject them.
                        </p>
                    </div>

                    <button
                        onClick={fetchBookings}
                        className="flex items-center gap-2 rounded-lg bg-slate-700 px-5 py-2.5 font-semibold text-white hover:bg-slate-800"
                    >
                        <RefreshCw size={17} />
                        Refresh
                    </button>
                </div>

                {/* Requests Bar */}
                <div className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-xl border border-orange-200 bg-orange-50 p-5">
                    <div className="flex items-center gap-3">
                        <div className="rounded-lg bg-orange-100 p-3 text-orange-600">
                            <Clock size={24} />
                        </div>

                        <div>
                            <h2 className="font-bold text-orange-900">
                                Requests & In Progress
                            </h2>

                            <p className="text-sm text-orange-700">
                                Pending decisions and accepted repairs
                            </p>
                        </div>
                    </div>

                    <div className="flex items-center gap-4">
                        <span className="rounded-full bg-orange-600 px-4 py-2 text-lg font-bold text-white">
                            {bookings.length}
                        </span>

                        <button
                            onClick={clearAllBookings}
                            disabled={bookings.length === 0}
                            className="rounded-lg bg-red-600 px-4 py-2.5 font-semibold text-white hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-40"
                        >
                            Clear All
                        </button>
                    </div>
                </div>

                {/* Messages */}
                {error && (
                    <div className="mb-5 rounded-lg bg-red-100 p-4 text-red-700">
                        {error}
                    </div>
                )}

                {message && (
                    <div className="mb-5 rounded-lg bg-green-100 p-4 text-green-700">
                        {message}
                    </div>
                )}

                {/* Booking Cards */}
                {bookings.length === 0 ? (
                    <div className="rounded-xl bg-white p-10 text-center shadow">
                        <ClipboardList
                            size={45}
                            className="mx-auto mb-4 text-slate-400"
                        />

                        <h2 className="text-xl font-semibold text-slate-800">
                            No Requests Available
                        </h2>

                        <p className="mt-2 text-slate-500">
                            New approved requests or accepted repairs will appear here.
                        </p>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                        {bookings.map((booking) => (
                            <div
                                key={booking._id}
                                className="relative rounded-xl border border-slate-200 bg-white p-6 shadow-sm transition hover:shadow-md"
                            >
                                {/* Individual Hide Button */}
                                <button
                                    onClick={() => dismissBooking(booking._id)}
                                    title="Hide this request"
                                    className="absolute right-4 top-4 rounded-full bg-red-100 p-2 text-red-600 transition hover:bg-red-600 hover:text-white"
                                >
                                    <X size={18} />
                                </button>

                                {/* Service and Status */}
                                <div className="mb-5 flex flex-wrap items-start justify-between gap-3 pr-10">
                                    <div>
                                        <h2 className="text-xl font-bold text-slate-900">
                                            {booking.serviceTitle ||
                                                booking.title ||
                                                "Repair Service"}
                                        </h2>

                                        <p className="mt-1 text-sm text-slate-500">
                                            {booking.serviceCategory || ""}
                                        </p>
                                    </div>

                                    {/* Dynamic Status */}
                                    <span
                                        className={`rounded-full px-3 py-1 text-sm font-semibold ${
                                            booking.status === "approved"
                                                ? "bg-orange-100 text-orange-700"
                                                : "bg-blue-100 text-blue-700"
                                        }`}
                                    >
                                        {booking.status === "approved"
                                            ? "Pending"
                                            : "In Progress"}
                                    </span>
                                </div>

                                {/* Customer Details */}
                                <div className="space-y-2 rounded-lg bg-slate-50 p-4">
                                    <p className="text-sm text-slate-700">
                                        <strong>Customer:</strong>{" "}
                                        {booking.customerName || "Not provided"}
                                    </p>

                                    <p className="text-sm text-slate-700">
                                        <strong>Email:</strong>{" "}
                                        {booking.customerEmail || "Not provided"}
                                    </p>

                                    <p className="text-sm text-slate-700">
                                        <strong>Phone:</strong>{" "}
                                        {booking.customerPhone || "Not provided"}
                                    </p>

                                    <p className="text-sm text-slate-700">
                                        <strong>Address:</strong>{" "}
                                        {booking.customerAddress || "Not provided"}
                                    </p>

                                    <p className="text-sm text-slate-700">
                                        <strong>Preferred Date:</strong>{" "}
                                        {booking.preferredDate
                                            ? new Date(
                                                booking.preferredDate
                                            ).toLocaleDateString()
                                            : "Not provided"}
                                    </p>

                                    <p className="text-sm text-slate-700">
                                        <strong>Base Price:</strong> $
                                        {booking.basePrice}
                                    </p>
                                </div>

                                {/* Problem Description */}
                                <div className="mt-4">
                                    <h3 className="mb-1 font-semibold text-slate-800">
                                        Problem Description
                                    </h3>

                                    <p className="break-words whitespace-pre-wrap text-sm leading-6 text-slate-600 [overflow-wrap:anywhere]">
                                        {booking.problemDescription ||
                                            "No description provided."}
                                    </p>
                                </div>

                                {/* Accept / Reject - Only Pending */}
                                {booking.status === "approved" && (
                                    <div className="mt-6 flex gap-3">
                                        <button
                                            disabled={updating}
                                            onClick={() =>
                                                updateStatus(
                                                    booking._id,
                                                    "accepted"
                                                )
                                            }
                                            className="flex-1 rounded-lg bg-green-600 px-4 py-3 font-semibold text-white transition hover:bg-green-700 disabled:opacity-50"
                                        >
                                            {updating
                                                ? "Updating..."
                                                : "Accept"}
                                        </button>

                                        <button
                                            disabled={updating}
                                            onClick={() =>
                                                updateStatus(
                                                    booking._id,
                                                    "rejected"
                                                )
                                            }
                                            className="flex-1 rounded-lg bg-red-600 px-4 py-3 font-semibold text-white transition hover:bg-red-700 disabled:opacity-50"
                                        >
                                            {updating
                                                ? "Updating..."
                                                : "Reject"}
                                        </button>
                                    </div>
                                )}

                                {/* Accepted Booking Notice */}
                                {(booking.status === "accepted" ||
                                    booking.status === "in-progress") && (
                                    <div className="mt-6 rounded-lg border border-blue-200 bg-blue-50 p-4 text-center">
                                        <p className="font-semibold text-blue-700">
                                            Repair In Progress
                                        </p>
                                        <p className="mt-1 text-sm text-blue-600">
                                            You have accepted this repair request.
                                        </p>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                )}

            </div>
        </div>
    );
}
