
"use client";

import { useState } from "react";
import { authClient } from "@/lib/auth-client";
import { getBackendToken } from "@/lib/getBackendToken";

export default function TestImageUpload() {
    const { data: session, isPending } = authClient.useSession();

    const [file, setFile] = useState(null);
    const [imageUrl, setImageUrl] = useState("");
    const [message, setMessage] = useState("");
    const [loading, setLoading] = useState(false);

    async function handleUpload() {
        if (!file) {
            setMessage("Please select an image first.");
            return;
        }

        try {
            setLoading(true);
            setMessage("");
            setImageUrl("");

            const token = await getBackendToken();

            const formData = new FormData();
            formData.append("image", file);

            const response = await fetch(
                `${process.env.NEXT_PUBLIC_API_URL}/api/services/upload-image`,
                {
                    method: "POST",
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                    body: formData,
                }
            );

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || "Upload failed");
            }

            setImageUrl(result.imageUrl);
            setMessage("Image uploaded successfully!");

        } catch (error) {
            setMessage(error.message);
        } finally {
            setLoading(false);
        }
    }

    if (isPending) {
        return <p className="p-10">Checking login...</p>;
    }

    if (!session?.user) {
        return <p className="p-10">Please sign in as a technician first.</p>;
    }

    return (
        <div className="mx-auto max-w-xl p-8">
            <h1 className="mb-6 text-2xl font-bold">
                Test ImgBB Image Upload
            </h1>

            <p className="mb-4 text-sm text-gray-600">
                Logged in as: {session.user.email}
            </p>

            <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                    setFile(e.target.files?.[0] || null);
                    setImageUrl("");
                    setMessage("");
                }}
                className="mb-5 block w-full"
            />

            <button
                onClick={handleUpload}
                disabled={loading || !file}
                className="rounded-lg bg-teal-700 px-6 py-3 font-semibold text-white disabled:opacity-50"
            >
                {loading ? "Uploading..." : "Upload Image"}
            </button>

            {message && (
                <p className="mt-5 font-medium">{message}</p>
            )}

            {imageUrl && (
                <div className="mt-6">
                    <p className="mb-2 font-semibold">Uploaded Image:</p>

                    <img
                        src={imageUrl}
                        alt="Uploaded service"
                        className="w-full rounded-xl"
                    />

                    <p className="mt-3 break-all text-sm text-gray-600">
                        {imageUrl}
                    </p>
                </div>
            )}
        </div>
    );
}
