
"use client";

import { useState } from "react";
import { getBackendToken } from "@/lib/getBackendToken";

export default function TestTechnician() {
    const [bookings, setBookings] = useState([]);
    const [message, setMessage] = useState("");
    const [loading, setLoading] = useState(false);

    async function fetchTechnicianBookings() {
        try {
            setLoading(true);
            setMessage("");

            const token = await getBackendToken();

            const response = await fetch(
                `${process.env.NEXT_PUBLIC_API_URL}/api/bookings/technician-bookings`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                    cache: "no-store",
                }
            );

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || "Failed to fetch bookings");
            }

            setBookings(result.data || []);
            setMessage(`Successfully loaded ${result.total} bookings`);

        } catch (error) {
            setMessage(error.message);
        } finally {
            setLoading(false);
        }
    }

    return (
        <main className="min-h-screen bg-slate-100 p-8">
            <div className="mx-auto max-w-4xl rounded-2xl bg-white p-8 shadow">

                <h1 className="text-2xl font-bold">
                    Technician Booking Test
                </h1>

                <button
                    onClick={fetchTechnicianBookings}
                    disabled={loading}
                    className="mt-6 rounded-xl bg-teal-700 px-6 py-3 font-semibold text-white disabled:opacity-50"
                >
                    {loading ? "Loading..." : "Load My Bookings"}
                </button>

                {message && (
                    <p className="mt-5 text-sm font-semibold">
                        {message}
                    </p>
                )}

                <div className="mt-6 space-y-4">
                    {bookings.map((booking) => (
                        <div
                            key={booking._id}
                            className="rounded-xl border p-5"
                        >
                            <h2 className="font-bold">
                                {booking.serviceTitle}
                            </h2>

                            <p>Customer: {booking.customerName}</p>
                            <p>Email: {booking.customerEmail}</p>
                            <p>Status: {booking.status}</p>
                            <p>Technician: {booking.technicianName}</p>
                        </div>
                    ))}
                </div>

            </div>
        </main>
    );
}
