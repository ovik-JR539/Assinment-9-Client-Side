
import express from "express";
import Stripe from "stripe";
import { ObjectId } from "mongodb";

import { getDB } from "../config/mongodb.js";
import { verifyToken } from "../middleware/verifyToken.js";

const router = express.Router();

// Stripe connection
function getStripe() {
    if (!process.env.STRIPE_SECRET_KEY) {
        throw new Error("Stripe secret key is missing");
    }

    return new Stripe(process.env.STRIPE_SECRET_KEY);
}

// Customer-only middleware
function verifyCustomer(req, res, next) {
    if (req.user.role !== "customer") {
        return res.status(403).json({
            success: false,
            message: "Only customers can make payments",
        });
    }

    next();
}

// ============================================
// CUSTOMER: CREATE CHECKOUT SESSION
// ============================================

router.post(
    "/create-checkout-session",
    verifyToken,
    verifyCustomer,
    async (req, res) => {
        try {
            const { bookingId } = req.body;

            if (!bookingId || !ObjectId.isValid(bookingId)) {
                return res.status(400).json({
                    success: false,
                    message: "A valid booking ID is required",
                });
            }

            const db = getDB();
            const bookings = db.collection("bookings");

            const booking = await bookings.findOne({
                _id: new ObjectId(bookingId),
                customerEmail: req.user.email,
            });

            if (!booking) {
                return res.status(404).json({
                    success: false,
                    message: "Booking not found",
                });
            }

            if (booking.status !== "completed") {
                return res.status(400).json({
                    success: false,
                    message: "You can only pay for completed repairs",
                });
            }

            if (booking.paymentStatus === "paid") {
                return res.status(400).json({
                    success: false,
                    message: "This booking has already been paid",
                });
            }

            const amount = Number(booking.finalAmount);

            if (!Number.isFinite(amount) || amount <= 0) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid final repair amount",
                });
            }

            const stripe = getStripe();

            // Reuse an existing open session
            if (booking.stripeCheckoutSessionId) {
                const existingSession =
                    await stripe.checkout.sessions.retrieve(
                        booking.stripeCheckoutSessionId
                    );

                if (existingSession.status === "open") {
                    return res.status(200).json({
                        success: true,
                        url: existingSession.url,
                    });
                }

                if (existingSession.payment_status === "paid") {
                    return res.status(409).json({
                        success: false,
                        message: "Payment is being processed. Please refresh your bookings.",
                    });
                }
            }

            const clientUrl = process.env.CLIENT_URL;

            if (!clientUrl) {
                throw new Error("CLIENT_URL is missing");
            }

            const session = await stripe.checkout.sessions.create({
                mode: "payment",
               
                customer_email: req.user.email,

                line_items: [
                    {
                        price_data: {
                            currency: "usd",
                            product_data: {
                                name: booking.serviceTitle || "FixMate Repair Service",
                                description: `Repair booking #${bookingId}`,
                            },
                            unit_amount: Math.round(amount * 100),
                        },
                        quantity: 1,
                    },
                ],

                metadata: {
                    bookingId,
                    customerEmail: req.user.email,
                },

                success_url: `${clientUrl}/dashboard/my-bookings?payment=success&session_id={CHECKOUT_SESSION_ID}`,

                cancel_url: `${clientUrl}/dashboard/my-bookings?payment=cancelled`,
            });

            await bookings.updateOne(
                {
                    _id: new ObjectId(bookingId),
                    customerEmail: req.user.email,
                    paymentStatus: { $ne: "paid" },
                },
                {
                    $set: {
                        stripeCheckoutSessionId: session.id,
                        updatedAt: new Date(),
                    },
                }
            );

            return res.status(200).json({
                success: true,
                url: session.url,
            });

        } catch (error) {
            console.error("Create Checkout Session error:", error.message);

            return res.status(500).json({
                success: false,
                message: "Unable to start payment. Please try again.",
            });
        }
    }
);


// ============================================
// STRIPE WEBHOOK: CONFIRM SUCCESSFUL PAYMENT
// ============================================

router.post("/webhook", async (req, res) => {
    const stripe = getStripe();

    let event;

    try {
        const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

        if (!webhookSecret) {
            throw new Error("Stripe webhook secret is missing");
        }

        if (!req.rawBody) {
            throw new Error("Raw webhook body is missing");
        }

        const signature = req.headers["stripe-signature"];

        event = stripe.webhooks.constructEvent(
            req.rawBody,
            signature,
            webhookSecret
        );

    } catch (error) {
        console.error("Webhook signature verification failed:", error.message);

        return res.status(400).json({
            success: false,
            message: "Invalid Stripe webhook signature",
        });
    }

    try {
        if (event.type === "checkout.session.completed") {
            const session = event.data.object;

            if (session.payment_status !== "paid") {
                return res.status(200).json({
                    received: true,
                    message: "Payment is not completed yet",
                });
            }

            const bookingId = session.metadata?.bookingId;
            const customerEmail = session.metadata?.customerEmail;

            if (!bookingId || !ObjectId.isValid(bookingId) || !customerEmail) {
                console.log("Ignoring test event without FixMate booking information");

                return res.status(200).json({
                    received: true,
                    message: "No FixMate booking associated with this event",
                });
            }

            if (session.currency !== "usd") {
                throw new Error("Unexpected payment currency");
            }

            const db = getDB();
            const bookings = db.collection("bookings");
            const payments = db.collection("payments");

            // Find the original booking
            const booking = await bookings.findOne({
                _id: new ObjectId(bookingId),
                customerEmail,
                status: "completed",
                stripeCheckoutSessionId: session.id,
            });

            if (!booking) {
                throw new Error("Matching completed booking not found");
            }

            // Verify the amount against the database
            const expectedAmount = Math.round(
                Number(booking.finalAmount) * 100
            );

            if (
                !Number.isFinite(expectedAmount) ||
                expectedAmount <= 0 ||
                session.amount_total !== expectedAmount
            ) {
                throw new Error("Stripe payment amount does not match booking amount");
            }

            // Prevent duplicate payment records
            await payments.createIndex(
                { stripeSessionId: 1 },
                { unique: true }
            );

            const paymentIntentId =
                typeof session.payment_intent === "string"
                    ? session.payment_intent
                    : session.payment_intent?.id || null;

            await payments.updateOne(
                { stripeSessionId: session.id },
                {
                    $setOnInsert: {
                        bookingId: new ObjectId(bookingId),
                        customerEmail,
                        technicianEmail: booking.technicianEmail,
                        serviceTitle: booking.serviceTitle,
                        amount: booking.finalAmount,
                        currency: "usd",
                        stripeSessionId: session.id,
                        stripePaymentIntentId: paymentIntentId,
                        status: "paid",
                        createdAt: new Date(),
                    },
                },
                { upsert: true }
            );

            // Update booking only if it has not already been paid
            await bookings.updateOne(
                {
                    _id: new ObjectId(bookingId),
                    customerEmail,
                    stripeCheckoutSessionId: session.id,
                    paymentStatus: { $ne: "paid" },
                },
                {
                    $set: {
                        paymentStatus: "paid",
                        paidAt: new Date(),
                        stripePaymentIntentId: paymentIntentId,
                        updatedAt: new Date(),
                    },
                }
            );

            console.log(`Payment confirmed for booking ${bookingId}`);
        }

        return res.status(200).json({
            received: true,
        });

    } catch (error) {
        console.error("Stripe webhook processing error:", error.message);

        return res.status(500).json({
            success: false,
            message: "Webhook processing failed",
        });
    }
});

export default router;
