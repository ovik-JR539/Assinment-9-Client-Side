
import express from "express";
import { ObjectId } from "mongodb";

import { getDB } from "../config/mongodb.js";
import { verifyToken } from "../middleware/verifyToken.js";

const router = express.Router();

// ============================================
// BANGLADESH DATE HELPER
// ============================================

function getTodayInBangladesh() {
    return new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Dhaka",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
    }).format(new Date());
}

// ============================================
// VALIDATE DATE
// ============================================

function isValidDateString(dateString) {
    if (typeof dateString !== "string") return false;

    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateString)) {
        return false;
    }

    const [year, month, day] = dateString.split("-").map(Number);

    const date = new Date(Date.UTC(year, month - 1, day));

    return (
        date.getUTCFullYear() === year &&
        date.getUTCMonth() === month - 1 &&
        date.getUTCDate() === day
    );
}

// ============================================
// VALIDATE TIME
// ============================================

function isValidTimeString(timeString) {
    return (
        typeof timeString === "string" &&
        /^([01]\d|2[0-3]):[0-5]\d$/.test(timeString)
    );
}

// ============================================
// ROLE MIDDLEWARE
// ============================================

function verifyCustomer(req, res, next) {
    if (req.user?.role !== "customer") {
        return res.status(403).json({
            success: false,
            message: "Only customers can access this resource",
        });
    }

    next();
}

function verifyTechnician(req, res, next) {
    if (req.user?.role !== "technician") {
        return res.status(403).json({
            success: false,
            message: "Only technicians can access this resource",
        });
    }

    next();
}

function verifyAdmin(req, res, next) {
    if (req.user?.role !== "admin") {
        return res.status(403).json({
            success: false,
            message: "Only admins can access this resource",
        });
    }

    next();
}

// ============================================
// CUSTOMER: GET MY BOOKINGS
// GET /api/bookings/my-bookings
// ============================================

router.get(
    "/my-bookings",
    verifyToken,
    verifyCustomer,
    async (req, res) => {
        try {
            const db = getDB();

            const bookings = await db.collection("bookings")
                .find({
                    customerEmail: req.user.email,
                })
                .sort({ createdAt: -1 })
                .toArray();

            return res.status(200).json({
                success: true,
                total: bookings.length,
                data: bookings,
            });

        } catch (error) {
            console.error("Fetch customer bookings error:", error);

            return res.status(500).json({
                success: false,
                message: "Failed to fetch bookings",
            });
        }
    }
);

// ============================================
// ADMIN: GET ALL BOOKINGS
// GET /api/bookings/admin-bookings
// ============================================

router.get(
    "/admin-bookings",
    verifyToken,
    verifyAdmin,
    async (req, res) => {
        try {
            const db = getDB();

            const bookings = await db.collection("bookings")
                .find({})
                .sort({ createdAt: -1 })
                .toArray();

            return res.status(200).json({
                success: true,
                total: bookings.length,
                data: bookings,
            });

        } catch (error) {
            console.error("Fetch admin bookings error:", error);

            return res.status(500).json({
                success: false,
                message: "Failed to fetch bookings",
            });
        }
    }
);

// ============================================
// ADMIN: APPROVE OR REJECT BOOKING
// PATCH /api/bookings/:id/admin-decision
// ============================================

router.patch(
    "/:id/admin-decision",
    verifyToken,
    verifyAdmin,
    async (req, res) => {
        try {
            const { id } = req.params;
            const { status } = req.body;

            if (!ObjectId.isValid(id)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid booking ID",
                });
            }

            if (!["approved", "rejected"].includes(status)) {
                return res.status(400).json({
                    success: false,
                    message: "Admin can only approve or reject bookings",
                });
            }

            const db = getDB();

            const result = await db.collection("bookings").updateOne(
                {
                    _id: new ObjectId(id),
                    status: "requested",
                },
                {
                    $set: {
                        status,
                        adminDecisionAt: new Date(),
                        updatedAt: new Date(),
                    },
                }
            );

            if (result.matchedCount === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Requested booking not found or already processed",
                });
            }

            return res.status(200).json({
                success: true,
                message: `Booking ${status} successfully`,
                status,
            });

        } catch (error) {
            console.error("Admin booking decision error:", error);

            return res.status(500).json({
                success: false,
                message: "Failed to update booking decision",
            });
        }
    }
);

// ============================================
// TECHNICIAN: GET MY BOOKINGS
// GET /api/bookings/technician-bookings
// ============================================

router.get(
    "/technician-bookings",
    verifyToken,
    verifyTechnician,
    async (req, res) => {
        try {
            const db = getDB();

            const bookings = await db.collection("bookings")
                .find({
                    technicianEmail: req.user.email,
                    status: {
                        $in: [
                            "approved",
                            "accepted",
                            "in-progress",
                            "completed",
                        ],
                    },
                })
                .sort({ createdAt: -1 })
                .toArray();

            return res.status(200).json({
                success: true,
                total: bookings.length,
                data: bookings,
            });

        } catch (error) {
            console.error("Fetch technician bookings error:", error);

            return res.status(500).json({
                success: false,
                message: "Failed to fetch bookings",
            });
        }
    }
);

// ============================================
// TECHNICIAN: UPDATE BOOKING STATUS
// PATCH /api/bookings/:id/status
// ============================================

router.patch(
    "/:id/status",
    verifyToken,
    verifyTechnician,
    async (req, res) => {
        try {
            const { id } = req.params;
            const { status, finalAmount, priceExplanation } = req.body;

            if (!ObjectId.isValid(id)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid booking ID",
                });
            }

            const allowedStatuses = [
                "accepted",
                "rejected",
                "in-progress",
                "completed",
            ];

            if (!allowedStatuses.includes(status)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid booking status",
                });
            }

            if (status === "completed") {
                if (
                    typeof finalAmount !== "number" ||
                    !Number.isFinite(finalAmount) ||
                    finalAmount <= 0
                ) {
                    return res.status(400).json({
                        success: false,
                        message: "Please provide a valid final repair amount",
                    });
                }

                if (
                    typeof priceExplanation !== "string" ||
                    !priceExplanation.trim()
                ) {
                    return res.status(400).json({
                        success: false,
                        message: "Please provide a description of the completed repair work",
                    });
                }

                if (priceExplanation.trim().length > 500) {
                    return res.status(400).json({
                        success: false,
                        message: "Repair description cannot exceed 500 characters",
                    });
                }
            }

            const db = getDB();
            const bookingsCollection = db.collection("bookings");

            const booking = await bookingsCollection.findOne({
                _id: new ObjectId(id),
                technicianEmail: req.user.email,
            });

            if (!booking) {
                return res.status(404).json({
                    success: false,
                    message: "Booking not found",
                });
            }

            const allowedTransitions = {
                approved: ["accepted", "rejected"],
                accepted: ["in-progress"],
                "in-progress": ["completed"],
            };

            const nextStatuses =
                allowedTransitions[booking.status] || [];

            if (!nextStatuses.includes(status)) {
                return res.status(400).json({
                    success: false,
                    message: `Cannot change booking from ${booking.status} to ${status}`,
                });
            }

            const updateFields = {
                status,
                updatedAt: new Date(),
            };

            if (status === "completed") {
                const basePrice = Number(booking.basePrice);

                if (!Number.isFinite(basePrice) || basePrice <= 0) {
                    return res.status(400).json({
                        success: false,
                        message: "Booking base price is unavailable",
                    });
                }

                updateFields.finalAmount = finalAmount;
                updateFields.priceExplanation = priceExplanation.trim();
                updateFields.completedAt = new Date();
            }

            const result = await bookingsCollection.updateOne(
                {
                    _id: new ObjectId(id),
                    technicianEmail: req.user.email,
                    status: booking.status,
                },
                {
                    $set: updateFields,
                }
            );

            if (result.modifiedCount === 0) {
                return res.status(409).json({
                    success: false,
                    message: "Booking status changed. Please refresh and try again.",
                });
            }

            return res.status(200).json({
                success: true,
                message: `Booking status updated to ${status}`,
                status,
                ...(status === "completed" && {
                    finalAmount,
                    priceExplanation: priceExplanation.trim(),
                    completedAt: updateFields.completedAt,
                }),
            });

        } catch (error) {
            console.error("Technician booking status error:", error);

            return res.status(500).json({
                success: false,
                message: "Failed to update booking status",
            });
        }
    }
);

// ============================================
// CUSTOMER: CANCEL BOOKING
// PATCH /api/bookings/:id/cancel
// ============================================

router.patch(
    "/:id/cancel",
    verifyToken,
    verifyCustomer,
    async (req, res) => {
        try {
            const { id } = req.params;

            if (!ObjectId.isValid(id)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid booking ID",
                });
            }

            const db = getDB();

            const result = await db.collection("bookings").updateOne(
                {
                    _id: new ObjectId(id),
                    customerEmail: req.user.email,
                    status: "requested",
                },
                {
                    $set: {
                        status: "cancelled",
                        updatedAt: new Date(),
                    },
                }
            );

            if (result.modifiedCount === 0) {
                return res.status(400).json({
                    success: false,
                    message: "Only requested bookings can be cancelled",
                });
            }

            return res.status(200).json({
                success: true,
                message: "Booking cancelled successfully",
            });

        } catch (error) {
            console.error("Booking cancellation error:", error);

            return res.status(500).json({
                success: false,
                message: "Failed to cancel booking",
            });
        }
    }
);

// ============================================
// CUSTOMER: CREATE REPAIR BOOKING
// POST /api/bookings
// ============================================

router.post(
    "/",
    verifyToken,
    verifyCustomer,
    async (req, res) => {
        try {
            const {
                serviceId,
                phone,
                address,
                bookingDate,
                bookingTime,
                problemDescription,
            } = req.body;

            // Required fields
            if (
                !serviceId ||
                !phone ||
                !address ||
                !bookingDate ||
                !bookingTime ||
                !problemDescription
            ) {
                return res.status(400).json({
                    success: false,
                    message: "Please complete all booking fields",
                });
            }

            // Validate service ID
            if (!ObjectId.isValid(serviceId)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid service ID",
                });
            }

            // Validate input types
            if (
                typeof phone !== "string" ||
                typeof address !== "string" ||
                typeof problemDescription !== "string"
            ) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid booking information",
                });
            }

            if (!phone.trim() || !address.trim()) {
                return res.status(400).json({
                    success: false,
                    message: "Phone and address cannot be empty",
                });
            }

            if (phone.trim().length < 8 || phone.trim().length > 20) {
                return res.status(400).json({
                    success: false,
                    message: "Please provide a valid phone number",
                });
            }

            if (address.trim().length < 5) {
                return res.status(400).json({
                    success: false,
                    message: "Please provide a complete repair address",
                });
            }

            if (problemDescription.trim().length < 20) {
                return res.status(400).json({
                    success: false,
                    message: "Problem description must be at least 20 characters",
                });
            }

            if (problemDescription.trim().length > 1000) {
                return res.status(400).json({
                    success: false,
                    message: "Problem description cannot exceed 1000 characters",
                });
            }

            // Validate date and time
            if (!isValidDateString(bookingDate)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid booking date",
                });
            }

            if (!isValidTimeString(bookingTime)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid booking time",
                });
            }

            const today = getTodayInBangladesh();

            if (bookingDate < today) {
                return res.status(400).json({
                    success: false,
                    message: "Booking date cannot be in the past",
                });
            }

            // Bangladesh time is UTC+6
            const bookingDateTime = new Date(
                `${bookingDate}T${bookingTime}:00+06:00`
            );

            if (bookingDateTime.getTime() <= Date.now()) {
                return res.status(400).json({
                    success: false,
                    message: "Please select a future booking time",
                });
            }

            const db = getDB();

            // Find the selected service from MongoDB.
            // Technician details are taken from this service,
            // NOT from the frontend request.
            const service = await db.collection("services").findOne({
                _id: new ObjectId(serviceId),
                isAvailable: true,
                isDeleted: { $ne: true },
            });

            if (!service) {
                return res.status(404).json({
                    success: false,
                    message: "Service not found or unavailable",
                });
            }

            if (
                !service.technicianEmail ||
                !service.technicianName
            ) {
                return res.status(400).json({
                    success: false,
                    message: "This service does not have an assigned technician",
                });
            }

            // Prevent duplicate active bookings
            const existingBooking = await db.collection("bookings").findOne({
                customerEmail: req.user.email,
                serviceId: service._id,
                status: {
                    $in: [
                        "requested",
                        "approved",
                        "accepted",
                        "in-progress",
                    ],
                },
            });

            if (existingBooking) {
                return res.status(409).json({
                    success: false,
                    message: "You already have an active request for this service",
                });
            }

            // Find authenticated customer
            const customer = await db.collection("user").findOne({
                email: req.user.email,
            });

            if (!customer) {
                return res.status(404).json({
                    success: false,
                    message: "Customer account not found",
                });
            }

            // Create booking document
            const booking = {
                serviceId: service._id,

                // Service information
                serviceTitle: service.title,
                serviceCategory: service.category,
                serviceImage: service.image,
                basePrice: service.basePrice,
                estimatedDuration: service.estimatedDuration,
                serviceMode: service.serviceMode,
                serviceArea: service.serviceArea,

                // Assigned technician from the service record
                technicianName: service.technicianName,
                technicianEmail: service.technicianEmail,

                // Authenticated customer information
                customerId: req.user.id,
                customerName: customer.name || "Customer",
                customerEmail: req.user.email,
                customerPhone: phone.trim(),
                customerAddress: address.trim(),

                // Booking schedule
                preferredDate: new Date(
                    `${bookingDate}T12:00:00.000Z`
                ),
                bookingDate,
                bookingTime,
                bookingDateTime,

                // Repair information
                problemDescription: problemDescription.trim(),

                // Booking status
                status: "requested",
                paymentStatus: "unpaid",

                createdAt: new Date(),
                updatedAt: new Date(),
            };

            const result = await db.collection("bookings").insertOne(booking);

            return res.status(201).json({
                success: true,
                message: "Repair request submitted successfully. Waiting for admin approval.",
                bookingId: result.insertedId,
                data: {
                    ...booking,
                    _id: result.insertedId,
                },
            });

        } catch (error) {
            console.error("Booking creation error:", error);

            return res.status(500).json({
                success: false,
                message: "Failed to create repair request",
            });
        }
    }
);

export default router;
