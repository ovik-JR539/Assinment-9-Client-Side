
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { authClient } from "@/lib/auth-client";
import { getBackendToken } from "@/lib/getBackendToken";

const categories = [
    "Smartphone",
    "Laptop & PC",
    "AC",
    "Refrigerator",
    "TV",
    "Washing Machine",
    "Electrical",
];

const serviceModes = ["Home Visit", "Shop Drop-off"];

const emptyForm = {
    title: "",
    category: "",
    description: "",
    image: "",
    basePrice: "",
    estimatedDuration: "",
    serviceMode: "",
    serviceArea: "",
};

export default function MyServices() {
    const router = useRouter();

    const { data: session, isPending } = authClient.useSession();

    const [services, setServices] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [message, setMessage] = useState("");

    const [selectedService, setSelectedService] = useState(null);
    const [form, setForm] = useState(emptyForm);
    const [imageFile, setImageFile] = useState(null);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        if (isPending) return;

        if (!session) {
            router.push("/sign-in");
            return;
        }

        if (session.user.role !== "technician") {
            router.push("/dashboard");
            return;
        }

        fetchMyServices();
    }, [session, isPending]);

    async function fetchMyServices() {
        try {
            setLoading(true);
            setError("");

            const token = await getBackendToken();

            const response = await fetch(
                `${process.env.NEXT_PUBLIC_API_URL}/api/services/my-services`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                    cache: "no-store",
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Failed to load services");
            }

            setServices(data.data || []);
        } catch (error) {
            setError(error.message);
        } finally {
            setLoading(false);
        }
    }

    function getStatusStyle(status) {
        if (status === "approved") {
            return "bg-green-100 text-green-700";
        }

        if (status === "rejected") {
            return "bg-red-100 text-red-700";
        }

        return "bg-yellow-100 text-yellow-700";
    }

    function openEditForm(service) {
        setSelectedService(service);

        setForm({
            title: service.title,
            category: service.category,
            description: service.description,
            image: service.image,
            basePrice: service.basePrice,
            estimatedDuration: service.estimatedDuration,
            serviceMode: service.serviceMode,
            serviceArea: service.serviceArea,
        });

        setImageFile(null);
        setError("");
        setMessage("");
    }

    function handleChange(event) {
        const { name, value } = event.target;

        setForm((previous) => ({
            ...previous,
            [name]: value,
        }));
    }

    async function handleUpdate(event) {
        event.preventDefault();

        try {
            setSaving(true);
            setError("");
            setMessage("");

            const token = await getBackendToken();

            let imageUrl = form.image;

            if (imageFile) {
                const imageData = new FormData();
                imageData.append("image", imageFile);

                const uploadResponse = await fetch(
                    `${process.env.NEXT_PUBLIC_API_URL}/api/services/upload-image`,
                    {
                        method: "POST",
                        headers: {
                            Authorization: `Bearer ${token}`,
                        },
                        body: imageData,
                    }
                );

                const uploadResult = await uploadResponse.json();

                if (!uploadResponse.ok) {
                    throw new Error(
                        uploadResult.message || "Image upload failed"
                    );
                }

                imageUrl = uploadResult.imageUrl;
            }

            const response = await fetch(
                `${process.env.NEXT_PUBLIC_API_URL}/api/services/${selectedService._id}`,
                {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                    body: JSON.stringify({
                        ...form,
                        image: imageUrl,
                        basePrice: Number(form.basePrice),
                    }),
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Failed to update service");
            }

            setMessage(
                "Service updated successfully! Waiting for admin approval."
            );

            setSelectedService(null);
            setImageFile(null);

            await fetchMyServices();

        } catch (error) {
            setError(error.message);
        } finally {
            setSaving(false);
        }
    }

    async function handleDelete(serviceId) {
        const confirmed = window.confirm(
            "Are you sure you want to delete this service?"
        );

        if (!confirmed) return;

        try {
            setError("");
            setMessage("");

            const token = await getBackendToken();

            const response = await fetch(
                `${process.env.NEXT_PUBLIC_API_URL}/api/services/${serviceId}`,
                {
                    method: "DELETE",
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Failed to delete service");
            }

            setServices((previous) =>
                previous.filter((service) => service._id !== serviceId)
            );

            setMessage("Service deleted successfully.");

        } catch (error) {
            setError(error.message);
        }
    }

    async function toggleAvailability(serviceId) {
        try {
            setError("");
            setMessage("");

            const token = await getBackendToken();

            const response = await fetch(
                `${process.env.NEXT_PUBLIC_API_URL}/api/services/${serviceId}/availability`,
                {
                    method: "PATCH",
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(
                    data.message || "Failed to update availability"
                );
            }

            setServices((previous) =>
                previous.map((service) =>
                    service._id === serviceId
                        ? {
                              ...service,
                              isAvailable: data.isAvailable,
                          }
                        : service
                )
            );

            setMessage(data.message);

        } catch (error) {
            setError(error.message);
        }
    }

    if (isPending || loading) {
        return (
            <div className="p-10 text-center">
                Loading your services...
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-slate-50 px-4 py-10">
            <div className="mx-auto max-w-7xl">

                <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
                    <div>
                        <h1 className="text-3xl font-bold text-slate-900">
                            My Services
                        </h1>

                        <p className="mt-2 text-slate-600">
                            Manage the repair services you have submitted.
                        </p>
                    </div>

                    <div className="flex gap-3">
                        <button
                            onClick={fetchMyServices}
                            className="rounded-lg bg-slate-700 px-4 py-2 text-white"
                        >
                            Refresh
                        </button>

                        <button
                            onClick={() =>
                                router.push("/dashboard/technician/add-service")
                            }
                            className="rounded-lg bg-orange-600 px-4 py-2 text-white"
                        >
                            + Add Service
                        </button>
                    </div>
                </div>

                {error && (
                    <div className="mb-6 rounded-lg bg-red-100 p-4 text-red-700">
                        {error}
                    </div>
                )}

                {message && (
                    <div className="mb-6 rounded-lg bg-green-100 p-4 text-green-700">
                        {message}
                    </div>
                )}

                {services.length === 0 ? (
                    <div className="rounded-xl bg-white p-10 text-center shadow">
                        <h2 className="text-xl font-semibold text-slate-800">
                            No services found
                        </h2>

                        <p className="mt-2 text-slate-500">
                            You haven`t submitted any services yet.
                        </p>
                    </div>
                ) : (
                    <div className="overflow-x-auto rounded-xl bg-white shadow">
                        <table className="w-full text-left">
                            <thead className="bg-slate-100 text-slate-700">
                                <tr>
                                    <th className="p-4">Service</th>
                                    <th className="p-4">Category</th>
                                    <th className="p-4">Price</th>
                                    <th className="p-4">Approval</th>
                                    <th className="p-4">Availability</th>
                                    <th className="p-4">Actions</th>
                                </tr>
                            </thead>

                            <tbody>
                                {services.map((service) => (
                                    <tr
                                        key={service._id}
                                        className="border-t border-slate-200"
                                    >
                                        <td className="p-4">
                                            <div className="flex items-center gap-3">
                                                <img
                                                    src={service.image}
                                                    alt={service.title}
                                                    className="h-14 w-14 rounded-lg object-cover"
                                                />

                                                <span className="font-semibold text-slate-800">
                                                    {service.title}
                                                </span>
                                            </div>
                                        </td>

                                        <td className="p-4 text-slate-600">
                                            {service.category}
                                        </td>

                                        <td className="p-4 font-semibold">
                                            ${service.basePrice}
                                        </td>

                                        <td className="p-4">
                                            <span
                                                className={`rounded-full px-3 py-1 text-sm font-semibold capitalize ${getStatusStyle(
                                                    service.approvalStatus
                                                )}`}
                                            >
                                                {service.approvalStatus}
                                            </span>
                                        </td>

                                        <td className="p-4">
                                            <button
                                                onClick={() =>
                                                    toggleAvailability(service._id)
                                                }
                                                className={`rounded-lg px-3 py-2 text-sm font-semibold ${
                                                    service.isAvailable
                                                        ? "bg-green-100 text-green-700"
                                                        : "bg-red-100 text-red-700"
                                                }`}
                                            >
                                                {service.isAvailable
                                                    ? "Available"
                                                    : "Unavailable"}
                                            </button>
                                        </td>

                                        <td className="p-4">
                                            <div className="flex flex-wrap gap-2">
                                                <button
                                                    onClick={() =>
                                                        openEditForm(service)
                                                    }
                                                    className="rounded-lg bg-blue-600 px-3 py-2 text-sm text-white hover:bg-blue-700"
                                                >
                                                    Edit
                                                </button>

                                                <button
                                                    onClick={() =>
                                                        handleDelete(service._id)
                                                    }
                                                    className="rounded-lg bg-red-600 px-3 py-2 text-sm text-white hover:bg-red-700"
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}

                {/* Edit Service Modal */}
                {selectedService && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/60 p-3 sm:p-5">

                        <div className="my-auto w-full max-w-5xl max-h-[95vh] overflow-y-auto rounded-2xl bg-white p-5 shadow-xl sm:p-7">

                            {/* Modal Header */}
                            <div className="mb-6 flex items-center justify-between">
                                <div>
                                    <h2 className="text-2xl font-bold text-slate-900">
                                        Edit Service
                                    </h2>

                                    <p className="mt-1 text-sm text-slate-500">
                                        Update your service information below.
                                    </p>
                                </div>

                                <button
                                    type="button"
                                    onClick={() => setSelectedService(null)}
                                    className="text-3xl leading-none text-slate-500 hover:text-red-600"
                                >
                                    &times;
                                </button>
                            </div>

                            <form onSubmit={handleUpdate}>

                                {/* Two-column form on desktop, one column on mobile */}
                                <div className="grid grid-cols-1 gap-x-6 gap-y-4 md:grid-cols-2">

                                    {/* Service Title */}
                                    <div>
                                        <label className="mb-1.5 block text-sm font-semibold text-slate-700">
                                            Service Title
                                        </label>

                                        <input
                                            name="title"
                                            value={form.title}
                                            onChange={handleChange}
                                            required
                                            className="w-full rounded-lg border border-slate-300 p-3 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100"
                                        />
                                    </div>

                                    {/* Category */}
                                    <div>
                                        <label className="mb-1.5 block text-sm font-semibold text-slate-700">
                                            Category
                                        </label>

                                        <select
                                            name="category"
                                            value={form.category}
                                            onChange={handleChange}
                                            required
                                            className="w-full rounded-lg border border-slate-300 p-3 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100"
                                        >
                                            {categories.map((category) => (
                                                <option key={category} value={category}>
                                                    {category}
                                                </option>
                                            ))}
                                        </select>
                                    </div>

                                    {/* Base Price */}
                                    <div>
                                        <label className="mb-1.5 block text-sm font-semibold text-slate-700">
                                            Base Price ($)
                                        </label>

                                        <input
                                            type="number"
                                            name="basePrice"
                                            value={form.basePrice}
                                            onChange={handleChange}
                                            required
                                            min="1"
                                            className="w-full rounded-lg border border-slate-300 p-3 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100"
                                        />
                                    </div>

                                    {/* Estimated Duration */}
                                    <div>
                                        <label className="mb-1.5 block text-sm font-semibold text-slate-700">
                                            Estimated Duration
                                        </label>

                                        <input
                                            name="estimatedDuration"
                                            value={form.estimatedDuration}
                                            onChange={handleChange}
                                            required
                                            placeholder="Example: 2 hours"
                                            className="w-full rounded-lg border border-slate-300 p-3 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100"
                                        />
                                    </div>

                                    {/* Service Mode */}
                                    <div>
                                        <label className="mb-1.5 block text-sm font-semibold text-slate-700">
                                            Service Mode
                                        </label>

                                        <select
                                            name="serviceMode"
                                            value={form.serviceMode}
                                            onChange={handleChange}
                                            required
                                            className="w-full rounded-lg border border-slate-300 p-3 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100"
                                        >
                                            {serviceModes.map((mode) => (
                                                <option key={mode} value={mode}>
                                                    {mode}
                                                </option>
                                            ))}
                                        </select>
                                    </div>

                                    {/* Service Area */}
                                    <div>
                                        <label className="mb-1.5 block text-sm font-semibold text-slate-700">
                                            Service Area
                                        </label>

                                        <input
                                            name="serviceArea"
                                            value={form.serviceArea}
                                            onChange={handleChange}
                                            required
                                            className="w-full rounded-lg border border-slate-300 p-3 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100"
                                        />
                                    </div>

                                    {/* Description takes full width */}
                                    <div className="md:col-span-2">
                                        <label className="mb-1.5 block text-sm font-semibold text-slate-700">
                                            Description
                                        </label>

                                        <textarea
                                            name="description"
                                            value={form.description}
                                            onChange={handleChange}
                                            required
                                            minLength={20}
                                            rows={3}
                                            className="w-full resize-y rounded-lg border border-slate-300 p-3 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100"
                                        />
                                    </div>

                                    {/* Image section */}
                                    <div className="md:col-span-2 rounded-xl border border-slate-200 bg-slate-50 p-4">

                                        <h3 className="mb-3 font-semibold text-slate-800">
                                            Service Image
                                        </h3>

                                        <div className="grid grid-cols-1 items-center gap-5 sm:grid-cols-[120px_1fr]">

                                            <div>
                                                <img
                                                    src={form.image}
                                                    alt="Current service"
                                                    className="h-28 w-full rounded-lg object-cover sm:w-28"
                                                />

                                                <p className="mt-2 text-center text-xs text-slate-500">
                                                    Current image
                                                </p>
                                            </div>

                                            <div>
                                                <label className="mb-2 block text-sm font-semibold text-slate-700">
                                                    Choose a new image (optional)
                                                </label>

                                                <input
                                                    type="file"
                                                    accept="image/*"
                                                    onChange={(event) => {
                                                        const file = event.target.files[0];

                                                        if (file && file.size > 5 * 1024 * 1024) {
                                                            setError("Image must be 5MB or smaller.");
                                                            event.target.value = "";
                                                            return;
                                                        }

                                                        setError("");
                                                        setImageFile(file || null);
                                                    }}
                                                    className="w-full rounded-lg border border-slate-300 bg-white p-2.5 text-sm"
                                                />

                                                {imageFile && (
                                                    <p className="mt-2 text-sm text-slate-500">
                                                        New image selected: {imageFile.name}
                                                    </p>
                                                )}

                                                <p className="mt-2 text-xs text-slate-500">
                                                    Maximum image size: 5MB.
                                                </p>
                                            </div>

                                        </div>
                                    </div>

                                </div>

                                {/* Form Buttons */}
                                <div className="mt-6 flex flex-col-reverse gap-3 border-t border-slate-200 pt-5 sm:flex-row sm:justify-end">

                                    <button
                                        type="button"
                                        onClick={() => setSelectedService(null)}
                                        className="rounded-lg bg-slate-200 px-6 py-3 font-semibold text-slate-700 hover:bg-slate-300"
                                    >
                                        Cancel
                                    </button>

                                    <button
                                        type="submit"
                                        disabled={saving}
                                        className="rounded-lg bg-orange-600 px-6 py-3 font-semibold text-white hover:bg-orange-700 disabled:opacity-50"
                                    >
                                        {saving ? "Saving..." : "Update Service"}
                                    </button>

                                </div>

                            </form>
                        </div>
                    </div>
                )}

            </div>
        </div>
    );
}
