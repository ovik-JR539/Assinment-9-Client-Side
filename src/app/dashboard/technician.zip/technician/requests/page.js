
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { authClient } from "@/lib/auth-client";
import { getBackendToken } from "@/lib/getBackendToken";

const filters = [
    "all",
    "requested",
    "accepted",
    "in-progress",
    "completed",
    "rejected",
];

export default function TechnicianRequests() {
    const router = useRouter();

    const { data: session, isPending } = authClient.useSession();

    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [updating, setUpdating] = useState(false);
    const [error, setError] = useState("");
    const [message, setMessage] = useState("");
    const [activeFilter, setActiveFilter] = useState("all");

    const [selectedBooking, setSelectedBooking] = useState(null);
    const [finalAmount, setFinalAmount] = useState("");

    useEffect(() => {
        if (isPending) return;

        if (!session) {
            router.push("/sign-in");
            return;
        }

        if (session.user.role !== "technician") {
            router.push("/dashboard");
            return;
        }

        fetchBookings();
    }, [session, isPending]);

    async function fetchBookings() {
        try {
            setLoading(true);
            setError("");

            const token = await getBackendToken();

            const response = await fetch(
                `${process.env.NEXT_PUBLIC_API_URL}/api/bookings/technician-bookings`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                    cache: "no-store",
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Failed to load requests");
            }

            setBookings(data.data || []);
        } catch (error) {
            setError(error.message);
        } finally {
            setLoading(false);
        }
    }

    async function updateStatus(bookingId, status, amount = null) {
        try {
            setUpdating(true);
            setError("");
            setMessage("");

            const token = await getBackendToken();

            const body = { status };

            if (amount !== null) {
                body.finalAmount = Number(amount);
            }

            const response = await fetch(
                `${process.env.NEXT_PUBLIC_API_URL}/api/bookings/${bookingId}/status`,
                {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                    body: JSON.stringify(body),
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Failed to update request");
            }

            setMessage(data.message || "Request updated successfully.");

            setSelectedBooking(null);
            setFinalAmount("");

            await fetchBookings();

        } catch (error) {
            setError(error.message);
        } finally {
            setUpdating(false);
        }
    }

    function openCompleteModal(booking) {
        setSelectedBooking(booking);
        setFinalAmount(
            String(booking.basePrice || booking.service?.basePrice || "")
        );
        setError("");
        setMessage("");
    }

    function handleComplete(event) {
        event.preventDefault();

        const amount = Number(finalAmount);

        if (!Number.isFinite(amount) || amount <= 0) {
            setError("Please enter a valid final amount.");
            return;
        }

        updateStatus(selectedBooking._id, "completed", amount);
    }

    function getStatusStyle(status) {
        const styles = {
            requested: "bg-yellow-100 text-yellow-700",
            accepted: "bg-blue-100 text-blue-700",
            "in-progress": "bg-purple-100 text-purple-700",
            completed: "bg-green-100 text-green-700",
            rejected: "bg-red-100 text-red-700",
            cancelled: "bg-slate-200 text-slate-700",
        };

        return styles[status] || "bg-slate-100 text-slate-700";
    }

    const filteredBookings = bookings.filter((booking) => {
        if (activeFilter === "all") return true;
        return booking.status === activeFilter;
    });

    if (isPending || loading) {
        return (
            <div className="p-10 text-center">
                Loading repair requests...
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-slate-50 px-4 py-10">
            <div className="mx-auto max-w-7xl">

                {/* Header */}
                <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
                    <div>
                        <h1 className="text-3xl font-bold text-slate-900">
                            Manage Requests
                        </h1>

                        <p className="mt-2 text-slate-600">
                            View and manage your assigned repair requests.
                        </p>
                    </div>

                    <button
                        onClick={fetchBookings}
                        className="rounded-lg bg-slate-700 px-5 py-2.5 font-semibold text-white hover:bg-slate-800"
                    >
                        Refresh Requests
                    </button>
                </div>

                {/* Messages */}
                {error && (
                    <div className="mb-5 rounded-lg bg-red-100 p-4 text-red-700">
                        {error}
                    </div>
                )}

                {message && (
                    <div className="mb-5 rounded-lg bg-green-100 p-4 text-green-700">
                        {message}
                    </div>
                )}

                {/* Status Filters */}
                <div className="mb-6 flex flex-wrap gap-2">
                    {filters.map((filter) => (
                        <button
                            key={filter}
                            onClick={() => setActiveFilter(filter)}
                            className={`rounded-lg px-4 py-2 text-sm font-semibold capitalize ${activeFilter === filter
                                    ? "bg-orange-600 text-white"
                                    : "bg-white text-slate-700 hover:bg-slate-100"
                                }`}
                        >
                            {filter.replace("-", " ")}
                            {filter === "all"
                                ? ` (${bookings.length})`
                                : ` (${bookings.filter(
                                    (booking) => booking.status === filter
                                ).length})`}
                        </button>
                    ))}
                </div>

                {/* Requests */}
                {filteredBookings.length === 0 ? (
                    <div className="rounded-xl bg-white p-10 text-center shadow">
                        <h2 className="text-xl font-semibold text-slate-800">
                            No requests found
                        </h2>

                        <p className="mt-2 text-slate-500">
                            There are no requests under this status.
                        </p>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                        {filteredBookings.map((booking) => (
                            <div
                                key={booking._id}
                                className="rounded-xl bg-white p-6 shadow"
                            >
                                {/* Service and Status */}
                                <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
                                    <div>
                                        <h2 className="text-xl font-bold text-slate-900">
                                            {booking.serviceTitle ||
                                                booking.title ||
                                                "Repair Service"}
                                        </h2>

                                        <p className="mt-1 text-sm text-slate-500">
                                            {booking.category || ""}
                                        </p>
                                    </div>

                                    <span
                                        className={`rounded-full px-3 py-1 text-sm font-semibold capitalize ${getStatusStyle(
                                            booking.status
                                        )}`}
                                    >
                                        {booking.status.replace("-", " ")}
                                    </span>
                                </div>

                                {/* Customer Details */}
                                <div className="space-y-2 rounded-lg bg-slate-50 p-4">
                                    <p className="text-sm text-slate-700">
                                        <strong>Customer:</strong>{" "}
                                        {booking.customerName}
                                    </p>

                                    <p className="text-sm text-slate-700">
                                        <strong>Email:</strong>{" "}
                                        {booking.customerEmail}
                                    </p>

                                    <p className="text-sm text-slate-700">
                                        <strong>Phone:</strong>{" "}
                                        {booking.phone || "Not provided"}
                                    </p>

                                    <p className="text-sm text-slate-700">
                                        <strong>Address:</strong>{" "}
                                        {booking.address || "Not provided"}
                                    </p>

                                    <p className="text-sm text-slate-700">
                                        <strong>Preferred Date:</strong>{" "}
                                        {booking.preferredDate
                                            ? new Date(
                                                booking.preferredDate
                                            ).toLocaleDateString()
                                            : "Not provided"}
                                    </p>

                                    <p className="text-sm text-slate-700">
                                        <strong>Base Price:</strong> $
                                        {booking.basePrice}
                                    </p>
                                </div>

                                {/* Problem Description */}
                                <div className="mt-4">
                                    <h3 className="mb-1 font-semibold text-slate-800">
                                        Problem Description
                                    </h3>

                                    <p className="break-words whitespace-pre-wrap [overflow-wrap:anywhere] text-sm leading-6 text-slate-600">
                                        {booking.problemDescription ||
                                            "No description provided."}
                                    </p>
                                </div>

                                {/* Final Amount */}
                                {booking.status === "completed" && (
                                    <div className="mt-4 rounded-lg bg-green-50 p-3">
                                        <p className="font-semibold text-green-700">
                                            Final Repair Amount: $
                                            {booking.finalAmount}
                                        </p>

                                        <p className="mt-1 text-sm text-slate-600">
                                            Payment Status:{" "}
                                            {booking.paymentStatus || "unpaid"}
                                        </p>
                                    </div>
                                )}

                                {/* Actions */}
                                <div className="mt-5 flex flex-wrap gap-3">

                                    {booking.status === "requested" && (
                                        <>
                                            <button
                                                disabled={updating}
                                                onClick={() =>
                                                    updateStatus(
                                                        booking._id,
                                                        "accepted"
                                                    )
                                                }
                                                className="rounded-lg bg-green-600 px-4 py-2 font-semibold text-white hover:bg-green-700 disabled:opacity-50"
                                            >
                                                Accept
                                            </button>

                                            <button
                                                disabled={updating}
                                                onClick={() =>
                                                    updateStatus(
                                                        booking._id,
                                                        "rejected"
                                                    )
                                                }
                                                className="rounded-lg bg-red-600 px-4 py-2 font-semibold text-white hover:bg-red-700 disabled:opacity-50"
                                            >
                                                Reject
                                            </button>
                                        </>
                                    )}

                                    {booking.status === "accepted" && (
                                        <button
                                            disabled={updating}
                                            onClick={() =>
                                                updateStatus(
                                                    booking._id,
                                                    "in-progress"
                                                )
                                            }
                                            className="rounded-lg bg-purple-600 px-4 py-2 font-semibold text-white hover:bg-purple-700 disabled:opacity-50"
                                        >
                                            Start Work
                                        </button>
                                    )}

                                    {booking.status === "in-progress" && (
                                        <button
                                            onClick={() =>
                                                openCompleteModal(booking)
                                            }
                                            className="rounded-lg bg-green-600 px-4 py-2 font-semibold text-white hover:bg-green-700"
                                        >
                                            Mark Completed
                                        </button>
                                    )}

                                    {["completed", "rejected", "cancelled"].includes(
                                        booking.status
                                    ) && (
                                            <p className="text-sm font-medium text-slate-500">
                                                No further actions available.
                                            </p>
                                        )}

                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {/* Complete Repair Modal */}
                {selectedBooking && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
                        <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl">

                            <h2 className="mb-2 text-2xl font-bold text-slate-900">
                                Complete Repair
                            </h2>

                            <p className="mb-5 text-sm text-slate-600">
                                Enter the final amount charged for this repair.
                            </p>

                            <form onSubmit={handleComplete}>
                                <label className="mb-2 block font-semibold text-slate-700">
                                    Final Amount ($)
                                </label>

                                <input
                                    type="number"
                                    min="1"
                                    step="0.01"
                                    required
                                    value={finalAmount}
                                    onChange={(event) =>
                                        setFinalAmount(event.target.value)
                                    }
                                    className="w-full rounded-lg border border-slate-300 p-3 outline-none focus:border-orange-500"
                                />

                                <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
                                    <button
                                        type="button"
                                        disabled={updating}
                                        onClick={() => {
                                            setSelectedBooking(null);
                                            setFinalAmount("");
                                        }}
                                        className="rounded-lg bg-slate-200 px-5 py-3 font-semibold text-slate-700"
                                    >
                                        Cancel
                                    </button>

                                    <button
                                        type="submit"
                                        disabled={updating}
                                        className="rounded-lg bg-green-600 px-5 py-3 font-semibold text-white disabled:opacity-50"
                                    >
                                        {updating
                                            ? "Updating..."
                                            : "Confirm Completion"}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}

            </div>
        </div>
    );
}
